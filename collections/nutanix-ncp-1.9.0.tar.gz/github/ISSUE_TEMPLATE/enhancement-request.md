---
name: Enhancement request
about: Use this to file enhancement
title: "[Imprv] add functionality <functionality_name> to module <module_name>"
labels: enhancement
assignees: alaa-bish, dina-abuhijleh, Gevorg-Khachatryan-97, premkarat

---

**Describe the request**

**Current behaviour**

**Expected behaviour**
