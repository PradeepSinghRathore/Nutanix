---
name: Feature request
about: Use this to file new functionality
title: "[Feat] Develop ansible module for <module_name>"
labels: feature
assignees: alaa-bish, dina-abuhijleh, Gevorg-Khachatryan-97, premkarat

---

Requirements:
- [ ] 
- [ ] 

Todo:
- [ ] Client SDK, get_spec()
- [ ] Ansible spec & spec validator
- [ ] Unit test, sanity test
- [ ] Integration test
- [ ] Documentation
- [ ] Examples
