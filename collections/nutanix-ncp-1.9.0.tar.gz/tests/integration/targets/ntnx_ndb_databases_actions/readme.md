### Modules Tested:
1. ntnx_ndb_database_log_catchup
2. ntnx_ndb_database_restore
3. ntnx_ndb_database_snapshots
4. ntnx_ndb_database_scale
5. ntnx_ndb_linked_databases