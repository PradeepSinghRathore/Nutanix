### Modules Tested:
1. HA instances using ntnx_ndb_databases