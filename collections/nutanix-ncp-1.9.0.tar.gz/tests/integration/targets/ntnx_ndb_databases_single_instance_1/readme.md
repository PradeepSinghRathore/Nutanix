### Modules Tested:
1. ntnx_ndb_databases
2. ntns_ndb_register_database